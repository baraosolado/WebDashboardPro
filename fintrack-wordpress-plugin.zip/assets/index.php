<?php
// Silêncio é dourado
// Este arquivo impede a listagem de diretórios